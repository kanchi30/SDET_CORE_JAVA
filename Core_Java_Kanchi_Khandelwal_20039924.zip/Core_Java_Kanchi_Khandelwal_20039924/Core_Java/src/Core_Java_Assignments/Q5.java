package Core_Java_Assignments;

import java.util.Scanner;

public class Q5 {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.print("Input first number: ");
		int a = obj.nextInt();
		System.out.print("Input second number number: ");
		int b = obj.nextInt();
		int temp;
		temp = a;
		a=b;
		b=temp;
		
		System.out.println("swapped numbers: " + a + " " + b);
		obj.close();
	}

}
