package Core_Java_Assignments;

import java.io.IOException;
import java.util.Scanner;

public class Q6 {

	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		int i=0;
		int carry=0;
		System.out.print("Input first binary number: ");
		long a = obj.nextLong();
		System.out.print("Input second number number: ");
		long b = obj.nextLong();
		long[] sum = new long [15];
		obj.close();
		while(a!=0 || b!=0)
		{
			sum[i] = (int)((a%10 + b%10 +carry)%2);
			carry = (int) ((a%10 + b%10 +carry)/2);
			a = a/10;
			b = b/10;
			i++;			
		}
		if (carry!=0)
		{
			sum[i] = carry;
		}
		System.out.print("Sum is : ");
		while(i >=0)
		{
			System.out.print(sum[i]);
			i--;
		}
	}

}
