package Core_Java_Assignments;

import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.print("Input a number: ");
		int a = obj.nextInt();
		obj.close();
		for(int i=1;i<=10;i++)
		{
			System.out.println(a + " x " + i + " = " + a*i);
		}
		

	}

}
