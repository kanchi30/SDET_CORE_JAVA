package Core_Java_Assignments;

import java.util.Scanner;

public class Q9 {
	static final double r =6371.01;
	public static double DistanceBetweenPoints(double a1,double a2,double b1,double b2)
	{
		double d=0;
		d=r*(Math.acos(Math.sin(a1)* Math.sin(a2) + (Math.cos(a1)* Math.cos(a2) * Math.cos(b1-b2))));
		return d;
	}

	public static void main(String[] args) {
		double a1,a2,b1,b2;
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter Latitude 1");
		a1 = Math.toRadians(obj.nextDouble());
		System.out.println("Enter Longitude 1");
		b1 = Math.toRadians(obj.nextDouble());
		System.out.println("Enter Latitude 2");
		a2 = Math.toRadians(obj.nextDouble());
		System.out.println("Enter Longitude 2");
		b2 = Math.toRadians(obj.nextDouble());
		obj.close();
		double distance = DistanceBetweenPoints(a1,a2,b1,b2);
		System.out.println("Distance between points(in kms): " + distance + " km");
		
	}

}
