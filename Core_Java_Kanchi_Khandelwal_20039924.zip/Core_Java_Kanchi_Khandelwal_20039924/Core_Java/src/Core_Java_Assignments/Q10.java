package Core_Java_Assignments;

import java.util.Scanner;

public class Q10 {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter String: ");
		String str = obj.nextLine();
		obj.close();
		char [] rev = str.toCharArray();
		char [] str1 = new char[str.length()];
		int i = 0;
		while(i<str.length())
		{
			str1[str.length()-1-i] = rev[i];
			i++;
		}
		System.out.println("Reverse of String: " + String.valueOf(str1));
		
	}

}
