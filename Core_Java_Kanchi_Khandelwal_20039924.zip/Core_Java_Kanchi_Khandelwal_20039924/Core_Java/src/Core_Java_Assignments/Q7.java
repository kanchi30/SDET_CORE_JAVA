package Core_Java_Assignments;

import java.util.Scanner;

public class Q7 {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.print("Input deimal number: ");
		int a = obj.nextInt();
		int[] num = new int[32];
		int i =0;
		while(i<32)
		{
			num[i] = a%2;
			a=a/2;
			if(a==0)
			{
				break;
			}
			i++;
		}
		System.out.print("Binary Number is: ");
		if(i==32)
		i--;
		while(i>=0)
		{
			System.out.print(num[i]);
			i--;
		}
		obj.close();
	}

}
