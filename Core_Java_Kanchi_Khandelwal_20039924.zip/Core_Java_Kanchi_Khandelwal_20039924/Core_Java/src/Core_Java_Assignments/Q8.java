package Core_Java_Assignments;

import java.util.Scanner;

public class Q8 {

	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.print("Input deimal number: ");
		int a = obj.nextInt();
		obj.close();
		int sum=0;
		while(a!=0)
		{
			sum=sum+a%10;
			a=a/10;
		}
		System.out.println("The sum of digits is : " + sum); 

	}

}
