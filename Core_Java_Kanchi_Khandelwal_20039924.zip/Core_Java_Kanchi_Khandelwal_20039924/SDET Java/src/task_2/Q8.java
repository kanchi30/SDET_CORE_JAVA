package task_2;

import java.util.Scanner;

public class Q8 {

		public static void main(String[] args) {
			Scanner obj = new Scanner(System.in);
			System.out.println("Enter array1 size:");
			int[] a = new int[obj.nextInt()];
			System.out.println("Enter values in array:");
			for(int i=0; i < a.length ; i++)
			{
				a[i] = obj.nextInt();
			}
			System.out.println("Enter array2 size:");
			int[] b = new int[obj.nextInt()];
			System.out.println("Enter values in array:");
			for(int i=0; i < b.length ; i++)
			{
				b[i] = obj.nextInt();
			}

			int[] result = new int[a.length + b.length];
			System.arraycopy(a, 0, result, 0, a.length);
			System.arraycopy(b, 0, result, a.length, b.length);
			for(int i=0; i < result.length ; i++)
			{
				System.out.print(result[i] + " ");
			}
			System.out.println();
			System.out.println("length of result: " + result.length);
			obj.close();
		}

}
