package task_2;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Q5 {
	int hour,min,sec;
	public void convertToTime(String time) throws Exception
	{
		
		Calendar cal = Calendar.getInstance();
		Date time1 = new SimpleDateFormat("HH-mm-ss").parse(time);
		cal.setTime(time1);
		this.hour = cal.get(Calendar.HOUR);
		this.min = cal.get(Calendar.MINUTE);
		this.sec = cal.get(Calendar.SECOND);
				
	}
	public static void diff(Q5 t1 , Q5 t2) throws Exception
	{
		int Dsec=0;
		int Dmin = 0;
		int Dhour=0;
	if(t1.sec < t2.sec)
	{
		System.out.println("in if of sec");
		Dsec = t1.sec+59 - t2.sec;
		t1.min--;
	}
	else
		Dsec = t1.sec- t2.sec;

	if(t1.min < t2.min)
	{
		System.out.println("in if of min");
		System.out.println(t1.min);
		System.out.println(t2.min);
		Dmin = t1.min+ 59 - t2.min;
		t1.hour--;
	}
	else
		Dmin = t1.min- t2.min;
	
	if(t1.sec < t2.sec)
	{
		throw new Exception("Incorrect Data");
	}
	else
		Dhour = t1.hour- t2.hour;
	
	System.out.println("Time Difference: " + Dhour + ":" + Dmin + ":" + Dsec );
	}
	
	public static void main(String[] args) throws Exception {
		Scanner obj =new Scanner (System.in);
		System.out.println("enter first time in hour, minutes , seconds : ");
		String time1 = obj.nextLine();
		System.out.println("enter first time in hour, minutes , seconds : ");
		String time2 = obj.nextLine();
		obj.close();
		Q5 t1 = new Q5();
		Q5 t2 = new Q5();
		t1.convertToTime(time1);
		t2.convertToTime(time2);
		diff(t1,t2);
	
	}

}
