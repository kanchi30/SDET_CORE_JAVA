package task_2;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Q7 {
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Date: ");
		String date = scanner.nextLine();
		Date sdate = new SimpleDateFormat("dd-MM-yyyy").parse(date);
		System.out.println(sdate);
		scanner.close();  
	}
}