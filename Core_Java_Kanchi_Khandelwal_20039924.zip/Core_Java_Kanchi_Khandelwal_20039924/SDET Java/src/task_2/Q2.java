package task_2;

import java.io.IOException;
import java.util.Scanner;

public class Q2 {
	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		int row1,col1,row2,col2;
		System.out.println("enter number of rows of matrix1:");
		row1 = obj.nextInt();
		System.out.println("enter number of column of matrix1:");
		col1 = obj.nextInt();
		System.out.println("enter number of rows of matrix2:");
		row2 = obj.nextInt();
		System.out.println("enter number of column of matrix2:");
		col2 = obj.nextInt();
		if(col1!=row2)
		{
			obj.close();
			throw new IOException("matrix row column mismatch");
		}
		int[][] matrix1 = new int[row1][col1];
		int[][] matrix2 = new int[row2][col2];
		int[][] matrix3 = new int[row1][col2];
		System.out.println("enter matrix1");
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				matrix1[i][j] = obj.nextInt();
			}
		}
		System.out.println("enter matrix2");
		for(int i=0; i<row2 ; i++)
		{
			for(int j=0; j<col2 ; j++)
			{
				matrix2[i][j] = obj.nextInt();
			}
		}
		int k=0;
		System.out.println("matrix multiplication: ");
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col2 ; j++)
			{
				for(k=0;k<row2 ;k++)
				{
					matrix3[i][j]= matrix3[i][j] +(matrix1[i][k]*matrix2[k][j]);
					
				}
				System.out.print(matrix3[i][j] + " \t ");
				
			}
			System.out.println();	

}
		obj.close();
}
}
