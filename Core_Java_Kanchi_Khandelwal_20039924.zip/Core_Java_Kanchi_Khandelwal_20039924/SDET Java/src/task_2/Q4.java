package task_2;

import java.util.Scanner;

public class Q4 {
public static void main(String[] args) {
		
		Scanner obj = new Scanner(System.in); 
		String str = new String();
		System.out.println("enter string:");
		str = obj.nextLine();
		char[] str1 = str.toCharArray();
		int i =0;
		System.out.println("enter the char to find ");
		char c = obj.next().charAt(0);
		int count =0;
		do 
		{ 
			if(str1[i]==c)
			{
				count++;
			}
			i++;
		}while(i<str.length());
		System.out.println("number of character frequency: " + count);
			obj.close();
 	}


}
