package task_2;

import java.util.Scanner;

public class Q1 {
	public static void main(String[] args )

	{
			Scanner obj = new Scanner(System.in);
			int row,col;
			System.out.println("enter number of rows:");
			row = obj.nextInt();
			System.out.println("enter number of column:");
			col = obj.nextInt();
			int[][] matrix1 = new int[row][col];
			int[][] matrix2 = new int[row][col];
			int[][] matrix3 = new int[row][col];
			System.out.println("enter matrix1");
			for(int i=0; i<row ; i++)
			{
				for(int j=0; j<col; j++)
				{
					matrix1[i][j] = obj.nextInt();
				}
			}
			System.out.println("enter matrix2");
			for(int i=0; i<row ; i++)
			{
				for(int j=0; j<col; j++)
				{
					matrix2[i][j] = obj.nextInt();
				}
			}
			
			System.out.println(" add of matrix: ");
			for(int i=0; i<row ; i++)
			{
				for(int j=0; j<col; j++)
				{
					matrix3[i][j]= matrix1[i][j]+matrix2[i][j];
					System.out.print(matrix3[i][j] + " \t");
				}
				System.out.println("\n");
			}
			obj.close();
	}	

}
