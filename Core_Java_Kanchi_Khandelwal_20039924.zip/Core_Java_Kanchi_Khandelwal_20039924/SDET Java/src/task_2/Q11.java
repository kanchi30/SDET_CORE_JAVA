package task_2;

public class Q11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
