package task_2;

import java.util.Scanner;

public class Q3 {
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		int row1=0,col1=0;
		System.out.println("enter number of rows of matrix1:");
		row1 = obj.nextInt();
		System.out.println("enter number of column of matrix1:");
		col1 = obj.nextInt();
		int[][] matrix1= new int[row1][col1];
		
		System.out.println("enter matrix1");
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				matrix1[i][j] = obj.nextInt();
			}
		}
		for(int j=0; j<col1 ; j++)
		{
			for(int i=0; i<row1 ; i++)
			{
				System.out.print(matrix1[i][j] + "\t");
			}
			System.out.println();
		}
		obj.close();

	}

}
