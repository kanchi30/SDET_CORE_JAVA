package task_2;

import java.util.Scanner;

public class Q9 {
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter String");
		String str = obj.nextLine();
		char[] ch = str.toCharArray();
		for(int i =0 ; i< ch.length;i++)
		{
			System.out.print(ch[i] + " ");
		}
		System.out.println("enter char");
		String str1 = String.valueOf(obj.next().charAt(0));
		System.out.print(str1);
		System.out.println("");
		obj.close();
		
	}
}
