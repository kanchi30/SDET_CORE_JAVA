package task_2;

import java.util.Scanner;

public class Q6 {
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = obj.nextLine();
		System.out.println("Before removing whitespaces: length of string: " + str.length());
		str = str.replaceAll("\\s", "");
		System.out.println("After removing Whitespaces:length is: " + str.length());
		System.out.println(str);
		obj.close();
	}

}
