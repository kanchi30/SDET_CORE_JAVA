package task_3;

import java.io.IOException;
import java.util.Scanner;

public class Q7 {
	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		int row1,col1;
		System.out.println("enter number of rows of matrix:");
		row1 = obj.nextInt();
		System.out.println("enter number of column of matrix:");
		col1 = obj.nextInt();
		System.out.println("enter matrix");
		int[][] matrix = new int[row1][col1];
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				matrix[i][j] = obj.nextInt();
			}
		}
		obj.close();
		int odd=0, even=0;
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				
				if(matrix[i][j]%2 ==0)
				{
					even++;
				}
				else 
				{
					odd++;
				}
			}			
		}
		System.out.println("count of odd numbers: " + odd);
		System.out.println("count of even numbers: " + even);
	}
}
