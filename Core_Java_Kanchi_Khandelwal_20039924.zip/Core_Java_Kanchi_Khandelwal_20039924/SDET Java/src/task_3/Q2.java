package task_3;

import java.util.Scanner;

public class Q2 {
	public static void main(String[] args)
	{
	Scanner obj = new Scanner(System.in);
	int k =0;
	System.out.println("Enter rows:");
	int row = obj.nextInt();
	System.out.println("Enter columns: ");
	int col = obj.nextInt();
	int[][] matrix = new int[row][col];
	if(row> col)
		k = row;
	else
		k = col;	
	int[] sum = new int[k];
	System.out.println("Enter matrix:");
	for(int i=0; i<row ; i++)
	{
		for(int j=0; j<col; j++)
		{
			matrix[i][j] = obj.nextInt();
		}
	}
	for( int i=0 ; i<row ; i++)
	{
		for(int j=0; j<col; j++)
		{
			sum[i] = sum[i] + matrix[i][j];
		}
		System.out.println(" Sum of row " + (i+1) + " is:" + sum[i] );
		sum[i]=0;
	}
	
	for( int i=0 ; i<col ; i++)
	{
		for(int j=0; j<row; j++)
		{
			sum[i] = sum[i] + matrix[j][i];
		}
		System.out.println(" Sum of column " + (i+1) + " is:" + sum[i] );
	}
	obj.close();
}
}
