package task_3;

public class Q9 {

    public static String compare(String s, String t){
		 int n = Math.min(s.length(),t.length());
    	for(int i =0 ; i<n; i++)
    	{
    		if(s.charAt(i)!=t.charAt(i))
    			return s.substring(0,i)  ;
    	}
    	return s.substring(0, n);
    }  
      
    public static void main (String[] args) {  
    	String str = "abcdabcd";
    	int num = str.length();
    	int len = 0;
    	String seq= " " ;
    	for(int i =0 ; i< str.length();i++)
    	{
    		for(int j=i+1;j<str.length();j++)
    		{
    			String ls = compare(str.substring(i, num),str.substring(j, num));
    			if(len <ls.length())
    			{
    				seq = ls;
    				len =ls.length();
    			}
    		}
    	}
    	System.out.println("longest seq: " + seq);

    }  
}
