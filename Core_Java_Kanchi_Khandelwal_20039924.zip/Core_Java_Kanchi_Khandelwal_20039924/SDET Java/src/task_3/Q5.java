package task_3;

import java.io.IOException;
import java.util.Scanner;

public class Q5 {

	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		int row1,col1;
		System.out.println("enter number of rows of matrix:");
		row1 = obj.nextInt();
		System.out.println("enter number of column of matrix:");
		col1 = obj.nextInt();
		if(row1!=col1)
		{
			obj.close();
			throw new IOException("matrix is not square");
		}
		System.out.println("enter matrix");
		int[][] matrix = new int[row1][col1];
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				matrix[i][j] = obj.nextInt();
			}
		}
		obj.close();
		System.out.println("Lower Triangular matrix: ");
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				if(i>j)
				{
					System.out.print("0" + "\t");
				}
				else 
				{
					System.out.print(matrix[i][j] + "\t");
				}
			}
			System.out.println();
		}
		

	}

}
