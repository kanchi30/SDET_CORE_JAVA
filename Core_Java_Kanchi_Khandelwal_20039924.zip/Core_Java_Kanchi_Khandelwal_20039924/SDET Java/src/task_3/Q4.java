package task_3;

import java.io.IOException;
import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		int row1,col1,row2,col2;
		System.out.println("enter number of rows of matrix1:");
		row1 = obj.nextInt();
		System.out.println("enter number of column of matrix1:");
		col1 = obj.nextInt();
		System.out.println("enter number of rows of matrix2:");
		row2 = obj.nextInt();
		System.out.println("enter number of column of matrix2:");
		col2 = obj.nextInt();
		if(row1!=row2 || col1!=col2)
		{
			obj.close();
			throw new IOException("matrix row column mismatch");
		}
		int[][] matrix1 = new int[row1][col1];
		int[][] matrix2 = new int[row2][col2];
		System.out.println("enter matrix1");
		for(int i=0; i<row1 ; i++)
		{
			for(int j=0; j<col1; j++)
			{
				matrix1[i][j] = obj.nextInt();
			}
		}
		System.out.println("enter matrix2");
		for(int i=0; i<row2 ; i++)
		{
			for(int j=0; j<col2 ; j++)
			{
				matrix2[i][j] = obj.nextInt();
			}
		}
		obj.close();
		float num = matrix1[0][0]/matrix2[0][0];
		for(int i=0; i<row2 ; i++)
		{
			for(int j=0; j<col2 ; j++)
			{
				if(num!= matrix1[i][j]/matrix2[i][j])
				throw new IOException("matrix not equal");
			}
		}
		System.out.println("Matrix are equal");
		
	}

}
