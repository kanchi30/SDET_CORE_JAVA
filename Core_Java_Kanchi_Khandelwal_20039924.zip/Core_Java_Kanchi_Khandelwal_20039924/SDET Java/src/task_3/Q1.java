package task_3;

import java.io.IOException;
import java.util.Scanner;

public class Q1 {
	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter rows: ");
		int row = obj.nextInt();
		System.out.println("Enter columns: ");
		int col = obj.nextInt();
		if(row!=col)
		{
			obj.close();
			throw new IOException("must be square matrix");
		}
		int[][] matrix = new int[row][col];
		System.out.println("Enter matrix to check:");
		for(int i=0; i<row ; i++)
		{
			for(int j=0; j<col; j++)
			{
				matrix[i][j] = obj.nextInt();
			}
		}
		obj.close();
		for(int i=0; i<row ; i++)
		{
			for(int j=0; j<col; j++)
			{
				if(i!=j)
				{
					if(matrix[i][j]!=0)
					throw new IOException("Not a Identity matrix");	
				}
				else
				{
					if(matrix[i][j]!=1)
						throw new IOException("Not a Identity matrix");	
				}
			}
		}
		System.out.println("It is a Identity Matrix");
		
	}

}
