package task_4;

import java.util.Scanner;

public class Q10 {
	public static void repeated(char[] c)
	{
		int count=0;
		for(int i=0 ; i < c.length ; i++)
		{
			count=0;
			for(char ch : c)
				{
				//System.out.println(c[i]);
						if(ch==c[i])
						count++;
				}
			if(count>1)
			{
				System.out.println("first repeated char: " + c[i]);
				break;
			}
				
		}
	
	}
	public static void nonRepeated(char[] c)
	{
		int count=0;
		for(int i=0 ; i < c.length ; i++)
		{
			count=0;
			for(char ch : c)
				{
				//System.out.println(c[i]);
						if(ch==c[i])
						count++;
				}
			if(count==1)
			{
				System.out.println("first non repeated char: " + c[i]);
				break;
			}
				
		}	
	}
	public static void main(String[] args)
	{
		Scanner obj= new Scanner(System.in);
		System.out.println("Enter String");
		String str = obj.nextLine();
		char[] c = str.toCharArray();
		repeated(c);
		nonRepeated(c);
		obj.close();

	}

}
