package task_4;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Q3 {

	public static void getCount(char[] charArray)
	{
		Map<Character,Integer> map = new HashMap<Character,Integer>();
		for(char ch : charArray)
		{
			if(map.containsKey(ch))
			{
				map.put(ch, map.get(ch)+1);
			}
			else
			{
				map.put(ch, 1);
			}
		}
		Set<Character> key = map.keySet();
		for(char ch : key)
		System.out.println(ch + " : " + map.get(ch));
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("ENter String: ");
		char[] charArray = scanner.nextLine().toCharArray();
		getCount(charArray);
		scanner.close();

	}

}
