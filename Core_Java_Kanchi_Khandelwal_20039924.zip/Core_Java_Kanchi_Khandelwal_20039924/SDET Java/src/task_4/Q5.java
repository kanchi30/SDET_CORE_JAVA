package task_4;

import java.util.Scanner;

public class Q5 {
	

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int[] array = {10,5,2,9,8,8};
		int num =0;
		System.out.println("Enter number");
		num = scanner.nextInt();
		scanner.close();
		int count=0;
		int sum=0;
		for(int i=0; i<array.length-1;i++)
		{
			sum=array[i];
			for(int j=i+1;j<array.length;j++)
			{
				
				 if(sum==num)
				 {
					 count++;
					 System.out.print("values are subarray whose sum is " + num + " :(");
					 for(int k = i; k<j ; k++)
					 {
							 System.out.print(array[k]+ " ");
					 }
					 System.out.print(")");
					 System.out.println();
					 break;
				 }
				 if (sum > num)
				 { 
					 break;
				 }
				 sum = sum + array[j];
				 }
			}
	
		if(count==0)
			System.out.println("No subarray who has sum as " + num + " is found.");
		}
	

}
