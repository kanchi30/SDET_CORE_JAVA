package task_4;

public class Q9 {
	public static int missingNum(int[] a)
	{
		int count=0;
		for(int i=1 ; i <= a.length+1 ; i++)
		{
			count=0;
			for(int num : a)
				{
					if(num==i)
						count++;
				}
			if(count==0)
				return i;
		}
		return 0;
		
		
	}

	public static void main(String[] args) {
		int[] a = {1,4,3,5,2};
		int num = missingNum(a);
		System.out.println("missing number: " + num );
		
	}

}
