package task_4;

import java.io.IOException;
import java.util.Scanner;

public class Q6 {

	public static void main(String[] args) throws IOException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter binary number to check: ");
		String str = scanner.nextLine();
		scanner.close();
		char[] charArray = str.toCharArray();
		for(char ch : charArray)
		{
			if(ch!='0' && ch!='1')
				throw new IOException("Not an binary number");
		}
	System.out.println("It is a Binary number");	
		

	}

}
