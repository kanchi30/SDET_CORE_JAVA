package task_4;

public class Q8 {
	
	public static void sortZero(int[] a)
	{
		int temp=0,k=0;
		for(int i =0 ; i<a.length;i++)
		{
			if(a[i]==0)
			{
				temp = a[i];
				a[i] = a[k];
				a[k] = temp;
				k++;
			}
		}
	}
	public static void main(String[] args) {
		int[] a = {12,0,1,-4,0,5,2,0,0, 5};
		sortZero(a);
		for(int i : a)
		System.out.print(i + " ");
		
	}

}
