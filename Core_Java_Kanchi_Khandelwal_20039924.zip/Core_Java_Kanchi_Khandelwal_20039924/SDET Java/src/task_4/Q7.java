package task_4;

import java.util.Scanner;

public class Q7 {

	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		System.out.println("ENter String");
		String str1 = scanner.nextLine();
		System.out.println("ENter rotated String");
		String str2 = scanner.nextLine();
		scanner.close();
		if(str1.length()!=str2.length())
		throw new Exception("String is not rotation of another");
		
		String str3 = str1.concat(str1);
		if(str3.contains(str2))
			System.out.println("String is rotation of another");
		else
			System.out.println("String is not rotation of another");
		
	}

}
