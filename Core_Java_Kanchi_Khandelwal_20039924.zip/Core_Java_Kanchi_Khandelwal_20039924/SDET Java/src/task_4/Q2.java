package task_4;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

public class Q2 {

	public static void main(String[] args) {
		int[] intArray = {10,85,35,65,55};
		SortedSet<Integer> set = new TreeSet<Integer>();
		for(int i : intArray)
		{
			set.add(i);
		}
		
		Iterator<Integer> itr = set.iterator();
		int secondLargest = 0;
		while(itr.hasNext())
		{
			if(itr.next()!=set.last())
				secondLargest = itr.next();
		}
		System.out.println(secondLargest);
	}
		
}
