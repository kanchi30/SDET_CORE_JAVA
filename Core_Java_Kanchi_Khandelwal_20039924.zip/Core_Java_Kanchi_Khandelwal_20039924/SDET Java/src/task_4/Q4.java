package task_4;

import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int[] array = { 4,5,7,11,9,13,8,12};
		int num =0;
		System.out.println("Enter number");
		num = scanner.nextInt();
		scanner.close();
		for(int i=0; i<array.length;i++)
		{
			for(int j= i+1; j<array.length;j++)
			{
				if(array[i]+array[j] == num)
				System.out.println("( " + array[i] + " , " + array[j] + " )");
			}
		}
	}

}
