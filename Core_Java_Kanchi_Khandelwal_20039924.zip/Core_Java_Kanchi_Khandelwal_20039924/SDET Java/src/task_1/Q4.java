package task_1;

import java.io.IOException;
import java.util.Scanner;

public class Q4 {
	public static void SwapNumbers( int a , int b)
	{
		a = a+b;
		b = a-b;
		a = a-b;
		System.out.println("swapped numbers: number 1=" + a + "\nnumber 2 = " + b);
		
	};
	public static void checkcondition(int T , int[] a, int []b) throws IOException
	{
		if(T>0 && T<=106)
		{
			for(int i = 0; i<T;i++)
			{
				if((a[i]>0&&a[i]<=106) && (b[i]>0&&b[i]<=106))
				{
				}
				else
				{
					throw new IOException(" not in range");
					
				}
			}
		}
		else
		{
			throw new IOException(" not in range");
		}
	}
	

	public static void main(String[] args) throws IOException {
		Scanner obj = new Scanner(System.in);
		int T;
		System.out.println("number of test cases:");
		T=obj.nextInt();
		if(T<1 || T>100)
		{
			obj.close();
			throw new IOException("out of bound");
		}
		int [] a= new int[T];
		int [] b = new int[T];
		for(int i = 0; i<T; i++)
		{
		a[i] = obj.nextInt();
		b[i] = obj.nextInt();
		}
		obj.close();
		checkcondition(T,a,b );
		for(int i=0; i<T; i++)
		{
			SwapNumbers(a[i],b[i]);
		}
		
	}
}
