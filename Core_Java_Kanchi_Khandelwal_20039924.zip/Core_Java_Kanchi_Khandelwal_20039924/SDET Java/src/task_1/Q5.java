package task_1;

import java.io.IOException;
import java.util.Scanner;

public class Q5 {
	public static void power_of_two(int value, int N, int count)
	{	
		int rem;
		if(N==1)
		{
			System.out.println("Yes");
		System.out.println( value + " is equal to 2 raised to the power " + count );
		}
		else
		{
			
			rem = N%2;
			N = N/2;
			if(rem==0)
			{	
				//System.out.println("divide");
				//System.out.println(N);
				count++;
				power_of_two(value,N,count);
			}
			else
			{
				System.out.println("No");
			}
		}
	}

	public static void main(String[] args) throws IOException{
		Scanner obj = new Scanner(System.in);
		int count=0;
		System.out.println("Enter the test cases ");
		int T = obj.nextInt();
		if(T<0||T>100)
		{
		obj.close();
		throw new IOException("OutofBound");
		}
		int[] N = new int[T];
		//System.out.println(N.length);
		for(int i = 0; i<T; i++)
		{
			N[i] = obj.nextInt();
			if(N[i]<0||N[i]>1018)
				{
				obj.close();
				throw new IOException("Invalid Input");
				}
		}
		for(int value : N)
		{
			count = 0;
			power_of_two(value,value, count);
		}
		obj.close();

	}


}
