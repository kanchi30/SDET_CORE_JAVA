package task_1;

public class Q2 {
	public static void main(String[] args) {
		int [] array = {10,20,30,40};
		int[] revarray = new int[array.length];
		
		for(int i=0; i<array.length;i++)
		{
			revarray[i]= array[array.length-(1+i)];
		}
		for(int value : revarray)
		{
			System.out.println(value);
		}
	}
}
