package task_1;

import java.util.Scanner;

public class Q1 {
	public static void main(String[] args) {
		Scanner obj = new Scanner ( System.in);
		System.out.println("Enter String: ");
		String string = new String(obj.nextLine());
		char[] reverse = string.toCharArray();
		char[] reverse1 = new char[reverse.length];
		for(int i=0 ;i<string.length() ; i++)
		{
			reverse1[i] =  reverse[reverse.length-(1+i)];
			
		};
		
		String Revstring = String.valueOf(reverse1);
		System.out.println("Reverse String: " + Revstring);
		obj.close();

}
}
