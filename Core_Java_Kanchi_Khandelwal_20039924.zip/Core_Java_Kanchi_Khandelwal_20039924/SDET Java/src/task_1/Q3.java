package task_1;

import java.util.Scanner;

public class Q3 {
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		int n,q;
		int large = 0;
		n = obj.nextInt();
		q = obj.nextInt();
		int[] A = new int[n];
		for ( int i=0; i<n ; i++)
		{
			A[i] = obj.nextInt();
		}
		int[] k = new int[q];
		for(int i =0; i< q ; i++ )
		{
			k[i] = obj.nextInt(); 
		}
		for(int value : k)
		{
			large = 0;
			for(int a : A)
			{
				if (value > a)
				{
					if(large < a)
					 large = a;
				}
			}
			System.out.println(large);
		}
		obj.close();
		
	}
}
